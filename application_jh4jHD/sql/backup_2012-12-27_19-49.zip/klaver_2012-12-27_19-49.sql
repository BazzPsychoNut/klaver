#
# TABLE STRUCTURE FOR: games
#

DROP TABLE IF EXISTS games;

CREATE TABLE `games` (
  `game_id` int(11) NOT NULL AUTO_INCREMENT,
  `match_id` int(11) NOT NULL,
  `points_team1` int(11) NOT NULL DEFAULT '0',
  `points_team2` int(11) NOT NULL DEFAULT '0',
  `roem_team1` int(11) NOT NULL DEFAULT '0',
  `roem_team2` int(11) NOT NULL DEFAULT '0',
  `special_team1` varchar(3) DEFAULT NULL,
  `special_team2` varchar(3) DEFAULT NULL,
  PRIMARY KEY (`game_id`),
  KEY `match_id` (`match_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: matches
#

DROP TABLE IF EXISTS matches;

CREATE TABLE `matches` (
  `match_id` int(11) NOT NULL AUTO_INCREMENT,
  `round` tinyint(4) NOT NULL,
  `poule_id` int(11) NOT NULL,
  `scheduled_date` date NOT NULL,
  `played_date` date DEFAULT NULL,
  `id_team1` int(11) NOT NULL,
  `id_team2` int(11) NOT NULL,
  `score_team1` int(11) DEFAULT NULL,
  `score_team2` int(11) DEFAULT NULL,
  PRIMARY KEY (`match_id`),
  KEY `team1_id` (`id_team1`,`id_team2`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=latin1;

INSERT INTO matches (`match_id`, `round`, `poule_id`, `scheduled_date`, `played_date`, `id_team1`, `id_team2`, `score_team1`, `score_team2`) VALUES (1, 1, 1, '2013-01-28', NULL, 1, 2, NULL, NULL);
INSERT INTO matches (`match_id`, `round`, `poule_id`, `scheduled_date`, `played_date`, `id_team1`, `id_team2`, `score_team1`, `score_team2`) VALUES (2, 2, 1, '2013-02-18', NULL, 1, 3, NULL, NULL);
INSERT INTO matches (`match_id`, `round`, `poule_id`, `scheduled_date`, `played_date`, `id_team1`, `id_team2`, `score_team1`, `score_team2`) VALUES (3, 3, 1, '2013-03-11', NULL, 1, 4, NULL, NULL);
INSERT INTO matches (`match_id`, `round`, `poule_id`, `scheduled_date`, `played_date`, `id_team1`, `id_team2`, `score_team1`, `score_team2`) VALUES (4, 4, 1, '2013-04-01', NULL, 1, 5, NULL, NULL);
INSERT INTO matches (`match_id`, `round`, `poule_id`, `scheduled_date`, `played_date`, `id_team1`, `id_team2`, `score_team1`, `score_team2`) VALUES (5, 5, 1, '2013-04-22', NULL, 1, 6, NULL, NULL);
INSERT INTO matches (`match_id`, `round`, `poule_id`, `scheduled_date`, `played_date`, `id_team1`, `id_team2`, `score_team1`, `score_team2`) VALUES (6, 6, 1, '2013-05-13', NULL, 1, 7, NULL, NULL);
INSERT INTO matches (`match_id`, `round`, `poule_id`, `scheduled_date`, `played_date`, `id_team1`, `id_team2`, `score_team1`, `score_team2`) VALUES (7, 7, 1, '2013-06-03', NULL, 1, 8, NULL, NULL);
INSERT INTO matches (`match_id`, `round`, `poule_id`, `scheduled_date`, `played_date`, `id_team1`, `id_team2`, `score_team1`, `score_team2`) VALUES (8, 3, 1, '2013-03-11', NULL, 2, 3, NULL, NULL);
INSERT INTO matches (`match_id`, `round`, `poule_id`, `scheduled_date`, `played_date`, `id_team1`, `id_team2`, `score_team1`, `score_team2`) VALUES (9, 4, 1, '2013-04-01', NULL, 2, 4, NULL, NULL);
INSERT INTO matches (`match_id`, `round`, `poule_id`, `scheduled_date`, `played_date`, `id_team1`, `id_team2`, `score_team1`, `score_team2`) VALUES (10, 5, 1, '2013-04-22', NULL, 2, 5, NULL, NULL);
INSERT INTO matches (`match_id`, `round`, `poule_id`, `scheduled_date`, `played_date`, `id_team1`, `id_team2`, `score_team1`, `score_team2`) VALUES (11, 6, 1, '2013-05-13', NULL, 2, 6, NULL, NULL);
INSERT INTO matches (`match_id`, `round`, `poule_id`, `scheduled_date`, `played_date`, `id_team1`, `id_team2`, `score_team1`, `score_team2`) VALUES (12, 7, 1, '2013-06-03', NULL, 2, 7, NULL, NULL);
INSERT INTO matches (`match_id`, `round`, `poule_id`, `scheduled_date`, `played_date`, `id_team1`, `id_team2`, `score_team1`, `score_team2`) VALUES (13, 8, 1, '2013-06-24', NULL, 2, 8, NULL, NULL);
INSERT INTO matches (`match_id`, `round`, `poule_id`, `scheduled_date`, `played_date`, `id_team1`, `id_team2`, `score_team1`, `score_team2`) VALUES (14, 5, 1, '2013-04-22', NULL, 3, 4, NULL, NULL);
INSERT INTO matches (`match_id`, `round`, `poule_id`, `scheduled_date`, `played_date`, `id_team1`, `id_team2`, `score_team1`, `score_team2`) VALUES (15, 6, 1, '2013-05-13', NULL, 3, 5, NULL, NULL);
INSERT INTO matches (`match_id`, `round`, `poule_id`, `scheduled_date`, `played_date`, `id_team1`, `id_team2`, `score_team1`, `score_team2`) VALUES (16, 7, 1, '2013-06-03', NULL, 3, 6, NULL, NULL);
INSERT INTO matches (`match_id`, `round`, `poule_id`, `scheduled_date`, `played_date`, `id_team1`, `id_team2`, `score_team1`, `score_team2`) VALUES (17, 8, 1, '2013-06-24', NULL, 3, 7, NULL, NULL);
INSERT INTO matches (`match_id`, `round`, `poule_id`, `scheduled_date`, `played_date`, `id_team1`, `id_team2`, `score_team1`, `score_team2`) VALUES (18, 1, 1, '2013-01-28', NULL, 3, 8, NULL, NULL);
INSERT INTO matches (`match_id`, `round`, `poule_id`, `scheduled_date`, `played_date`, `id_team1`, `id_team2`, `score_team1`, `score_team2`) VALUES (19, 7, 1, '2013-06-03', NULL, 4, 5, NULL, NULL);
INSERT INTO matches (`match_id`, `round`, `poule_id`, `scheduled_date`, `played_date`, `id_team1`, `id_team2`, `score_team1`, `score_team2`) VALUES (20, 8, 1, '2013-06-24', NULL, 4, 6, NULL, NULL);
INSERT INTO matches (`match_id`, `round`, `poule_id`, `scheduled_date`, `played_date`, `id_team1`, `id_team2`, `score_team1`, `score_team2`) VALUES (21, 1, 1, '2013-01-28', NULL, 4, 7, NULL, NULL);
INSERT INTO matches (`match_id`, `round`, `poule_id`, `scheduled_date`, `played_date`, `id_team1`, `id_team2`, `score_team1`, `score_team2`) VALUES (22, 2, 1, '2013-02-18', NULL, 4, 8, NULL, NULL);
INSERT INTO matches (`match_id`, `round`, `poule_id`, `scheduled_date`, `played_date`, `id_team1`, `id_team2`, `score_team1`, `score_team2`) VALUES (23, 1, 1, '2013-01-28', NULL, 5, 6, NULL, NULL);
INSERT INTO matches (`match_id`, `round`, `poule_id`, `scheduled_date`, `played_date`, `id_team1`, `id_team2`, `score_team1`, `score_team2`) VALUES (24, 2, 1, '2013-02-18', NULL, 5, 7, NULL, NULL);
INSERT INTO matches (`match_id`, `round`, `poule_id`, `scheduled_date`, `played_date`, `id_team1`, `id_team2`, `score_team1`, `score_team2`) VALUES (25, 3, 1, '2013-03-11', NULL, 5, 8, NULL, NULL);
INSERT INTO matches (`match_id`, `round`, `poule_id`, `scheduled_date`, `played_date`, `id_team1`, `id_team2`, `score_team1`, `score_team2`) VALUES (26, 3, 1, '2013-03-11', NULL, 6, 7, NULL, NULL);
INSERT INTO matches (`match_id`, `round`, `poule_id`, `scheduled_date`, `played_date`, `id_team1`, `id_team2`, `score_team1`, `score_team2`) VALUES (27, 4, 1, '2013-04-01', NULL, 6, 8, NULL, NULL);
INSERT INTO matches (`match_id`, `round`, `poule_id`, `scheduled_date`, `played_date`, `id_team1`, `id_team2`, `score_team1`, `score_team2`) VALUES (28, 5, 1, '2013-04-22', NULL, 7, 8, NULL, NULL);


#
# TABLE STRUCTURE FOR: matches_backup
#

DROP TABLE IF EXISTS matches_backup;

CREATE TABLE `matches_backup` (
  `match_id` int(11) NOT NULL DEFAULT '0',
  `round` tinyint(4) NOT NULL,
  `poule_id` int(11) NOT NULL,
  `scheduled_date` date NOT NULL,
  `played_date` date DEFAULT NULL,
  `id_team1` int(11) NOT NULL,
  `id_team2` int(11) NOT NULL,
  `score_team1` int(11) DEFAULT NULL,
  `score_team2` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

INSERT INTO matches_backup (`match_id`, `round`, `poule_id`, `scheduled_date`, `played_date`, `id_team1`, `id_team2`, `score_team1`, `score_team2`) VALUES (1, 1, 1, '2012-09-09', NULL, 1, 2, 1000, 600);


#
# TABLE STRUCTURE FOR: players
#

DROP TABLE IF EXISTS players;

CREATE TABLE `players` (
  `player_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `password` char(32) NOT NULL,
  `email` text NOT NULL,
  `level` tinyint(4) NOT NULL DEFAULT '1',
  `team_id` int(11) NOT NULL,
  PRIMARY KEY (`player_id`),
  KEY `team_id` (`team_id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=latin1;

INSERT INTO players (`player_id`, `name`, `password`, `email`, `level`, `team_id`) VALUES (1, 'dummy1', 'p', 'e', 1, 1);
INSERT INTO players (`player_id`, `name`, `password`, `email`, `level`, `team_id`) VALUES (2, 'dummy2', 'p', 'e', 1, 1);
INSERT INTO players (`player_id`, `name`, `password`, `email`, `level`, `team_id`) VALUES (3, 'dummy3', 'p', 'e', 1, 2);
INSERT INTO players (`player_id`, `name`, `password`, `email`, `level`, `team_id`) VALUES (4, 'dummy4', 'p', 'e', 1, 2);
INSERT INTO players (`player_id`, `name`, `password`, `email`, `level`, `team_id`) VALUES (5, 'dummy5', 'p', 'e', 1, 3);
INSERT INTO players (`player_id`, `name`, `password`, `email`, `level`, `team_id`) VALUES (6, 'dummy6', 'p', 'e', 1, 3);
INSERT INTO players (`player_id`, `name`, `password`, `email`, `level`, `team_id`) VALUES (7, 'dummy7', 'p', 'e', 1, 4);
INSERT INTO players (`player_id`, `name`, `password`, `email`, `level`, `team_id`) VALUES (8, 'dummy8', 'p', 'e', 1, 4);
INSERT INTO players (`player_id`, `name`, `password`, `email`, `level`, `team_id`) VALUES (9, 'dummy9', 'p', 'e', 1, 5);
INSERT INTO players (`player_id`, `name`, `password`, `email`, `level`, `team_id`) VALUES (10, 'dummy10', 'p', 'e', 1, 5);
INSERT INTO players (`player_id`, `name`, `password`, `email`, `level`, `team_id`) VALUES (11, 'dummy11', 'p', 'e', 1, 6);
INSERT INTO players (`player_id`, `name`, `password`, `email`, `level`, `team_id`) VALUES (12, 'dummy12', 'p', 'e', 1, 6);
INSERT INTO players (`player_id`, `name`, `password`, `email`, `level`, `team_id`) VALUES (13, 'dummy13', 'p', 'e', 1, 7);
INSERT INTO players (`player_id`, `name`, `password`, `email`, `level`, `team_id`) VALUES (14, 'dummy14', 'p', 'e', 1, 7);
INSERT INTO players (`player_id`, `name`, `password`, `email`, `level`, `team_id`) VALUES (15, 'dummy15', 'p', 'e', 1, 8);
INSERT INTO players (`player_id`, `name`, `password`, `email`, `level`, `team_id`) VALUES (16, 'dummy16', 'p', 'e', 1, 8);
INSERT INTO players (`player_id`, `name`, `password`, `email`, `level`, `team_id`) VALUES (17, 'dummy17', 'p', 'e', 1, 9);
INSERT INTO players (`player_id`, `name`, `password`, `email`, `level`, `team_id`) VALUES (18, 'dummy18', 'p', 'e', 1, 9);
INSERT INTO players (`player_id`, `name`, `password`, `email`, `level`, `team_id`) VALUES (19, 'dummy19', 'p', 'e', 1, 10);
INSERT INTO players (`player_id`, `name`, `password`, `email`, `level`, `team_id`) VALUES (20, 'dummy20', 'p', 'e', 1, 10);
INSERT INTO players (`player_id`, `name`, `password`, `email`, `level`, `team_id`) VALUES (21, 'dummy21', 'p', 'e', 1, 11);
INSERT INTO players (`player_id`, `name`, `password`, `email`, `level`, `team_id`) VALUES (22, 'dummy22', 'p', 'e', 1, 11);
INSERT INTO players (`player_id`, `name`, `password`, `email`, `level`, `team_id`) VALUES (23, 'dummy23', 'p', 'e', 1, 12);
INSERT INTO players (`player_id`, `name`, `password`, `email`, `level`, `team_id`) VALUES (24, 'dummy24', 'p', 'e', 1, 12);
INSERT INTO players (`player_id`, `name`, `password`, `email`, `level`, `team_id`) VALUES (25, 'dummy25', 'p', 'e', 1, 13);
INSERT INTO players (`player_id`, `name`, `password`, `email`, `level`, `team_id`) VALUES (26, 'dummy26', 'p', 'e', 1, 13);
INSERT INTO players (`player_id`, `name`, `password`, `email`, `level`, `team_id`) VALUES (27, 'dummy27', 'p', 'e', 1, 14);
INSERT INTO players (`player_id`, `name`, `password`, `email`, `level`, `team_id`) VALUES (28, 'dummy28', 'p', 'e', 1, 14);
INSERT INTO players (`player_id`, `name`, `password`, `email`, `level`, `team_id`) VALUES (29, 'dummy29', 'p', 'e', 1, 15);
INSERT INTO players (`player_id`, `name`, `password`, `email`, `level`, `team_id`) VALUES (30, 'dummy30', 'p', 'e', 1, 15);
INSERT INTO players (`player_id`, `name`, `password`, `email`, `level`, `team_id`) VALUES (31, 'dummy31', 'p', 'e', 1, 16);
INSERT INTO players (`player_id`, `name`, `password`, `email`, `level`, `team_id`) VALUES (32, 'dummy32', 'p', 'e', 1, 16);


#
# TABLE STRUCTURE FOR: poules
#

DROP TABLE IF EXISTS poules;

CREATE TABLE `poules` (
  `poule_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  PRIMARY KEY (`poule_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO poules (`poule_id`, `name`) VALUES (1, 'Poule A');
INSERT INTO poules (`poule_id`, `name`) VALUES (2, 'Poule B');


#
# TABLE STRUCTURE FOR: teams
#

DROP TABLE IF EXISTS teams;

CREATE TABLE `teams` (
  `team_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `poule_id` int(11) NOT NULL,
  `played` tinyint(4) NOT NULL DEFAULT '0',
  `wins` tinyint(4) NOT NULL DEFAULT '0',
  `losses` tinyint(4) NOT NULL DEFAULT '0',
  `score` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`team_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;

INSERT INTO teams (`team_id`, `name`, `poule_id`, `played`, `wins`, `losses`, `score`) VALUES (1, 'Team 1', 1, 0, 0, 0, 0);
INSERT INTO teams (`team_id`, `name`, `poule_id`, `played`, `wins`, `losses`, `score`) VALUES (2, 'Team 2', 1, 0, 0, 0, 0);
INSERT INTO teams (`team_id`, `name`, `poule_id`, `played`, `wins`, `losses`, `score`) VALUES (3, 'Team 3', 1, 0, 0, 0, 0);
INSERT INTO teams (`team_id`, `name`, `poule_id`, `played`, `wins`, `losses`, `score`) VALUES (4, 'Team 4', 1, 0, 0, 0, 0);
INSERT INTO teams (`team_id`, `name`, `poule_id`, `played`, `wins`, `losses`, `score`) VALUES (5, 'Team 5', 1, 0, 0, 0, 0);
INSERT INTO teams (`team_id`, `name`, `poule_id`, `played`, `wins`, `losses`, `score`) VALUES (6, 'Team 6', 1, 0, 0, 0, 0);
INSERT INTO teams (`team_id`, `name`, `poule_id`, `played`, `wins`, `losses`, `score`) VALUES (7, 'Team 7', 1, 0, 0, 0, 0);
INSERT INTO teams (`team_id`, `name`, `poule_id`, `played`, `wins`, `losses`, `score`) VALUES (8, 'Team 8', 1, 0, 0, 0, 0);
INSERT INTO teams (`team_id`, `name`, `poule_id`, `played`, `wins`, `losses`, `score`) VALUES (9, 'Team 9', 2, 0, 0, 0, 0);
INSERT INTO teams (`team_id`, `name`, `poule_id`, `played`, `wins`, `losses`, `score`) VALUES (10, 'Team 10', 2, 0, 0, 0, 0);
INSERT INTO teams (`team_id`, `name`, `poule_id`, `played`, `wins`, `losses`, `score`) VALUES (11, 'Team 11', 2, 0, 0, 0, 0);
INSERT INTO teams (`team_id`, `name`, `poule_id`, `played`, `wins`, `losses`, `score`) VALUES (12, 'Team 12', 2, 0, 0, 0, 0);
INSERT INTO teams (`team_id`, `name`, `poule_id`, `played`, `wins`, `losses`, `score`) VALUES (13, 'Team 13', 2, 0, 0, 0, 0);
INSERT INTO teams (`team_id`, `name`, `poule_id`, `played`, `wins`, `losses`, `score`) VALUES (14, 'Team 14', 2, 0, 0, 0, 0);
INSERT INTO teams (`team_id`, `name`, `poule_id`, `played`, `wins`, `losses`, `score`) VALUES (15, 'Team 15', 2, 0, 0, 0, 0);
INSERT INTO teams (`team_id`, `name`, `poule_id`, `played`, `wins`, `losses`, `score`) VALUES (16, 'Team 16', 2, 0, 0, 0, 0);


